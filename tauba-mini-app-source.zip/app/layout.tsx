import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'TAUBA TOUR — поездка к святыням',description:'Демонстрационный Mini App TAUBA TOUR'};
export const viewport: Viewport = {width:'device-width',initialScale:1,viewportFit:'cover'};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="ru"><head><script src="https://telegram.org/js/telegram-web-app.js" defer /></head><body>{children}</body></html>; }
