import { db } from '@/lib/db';
import { apiError } from '@/lib/api';
export const dynamic = 'force-dynamic';
export async function GET() {
  try { return Response.json(await db.tour.findMany({where:{isPublished:true,isArchived:false},orderBy:[{startDate:'asc'},{createdAt:'asc'}]})); }
  catch(error) { return apiError(error); }
}
