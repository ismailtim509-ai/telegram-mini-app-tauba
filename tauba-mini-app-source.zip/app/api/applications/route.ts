import { db } from '@/lib/db';
import { getIdentity } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { applicationSchema } from '@/lib/validation';
import { notifyManager } from '@/lib/manager-notification';

export async function GET(request: Request) {
  try { const user=getIdentity(request); return Response.json(await db.application.findMany({where:{telegramId:user.id},include:{tour:{select:{title:true,dateLabel:true,price:true,currency:true}}},orderBy:{createdAt:'desc'}})); }
  catch(error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    const user=getIdentity(request);
    const data=applicationSchema.parse(await request.json());
    const recent=await db.application.findFirst({where:{telegramId:user.id,createdAt:{gte:new Date(Date.now()-30_000)}},select:{id:true}});
    if (recent) return Response.json({error:'Подождите немного перед повторной отправкой'},{status:429});
    const tour=await db.tour.findFirst({where:{id:data.tourId,isPublished:true,isArchived:false,status:{not:'soldout'}}});
    if (!tour) return Response.json({error:'Тур недоступен для заявки'},{status:404});
    const application=await db.application.create({data:{telegramId:user.id,tourId:tour.id,name:data.name,phone:data.phone,people:data.people,comment:data.comment,consentAt:new Date()}});
    await notifyManager(application,tour.title);
    return Response.json({id:application.id,status:application.status},{status:201});
  } catch(error) { return apiError(error); }
}
