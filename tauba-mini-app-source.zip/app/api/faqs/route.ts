import { db } from '@/lib/db';
import { apiError } from '@/lib/api';
export const dynamic = 'force-dynamic';
export async function GET() {
  try { return Response.json(await db.faq.findMany({where:{isPublished:true},orderBy:{sortOrder:'asc'}})); }
  catch(error) { return apiError(error); }
}
