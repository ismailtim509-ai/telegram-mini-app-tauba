import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { tourSchema } from '@/lib/validation';
export async function PATCH(request: Request, context:{params:Promise<{id:string}>}) {
  try { requireAdmin(request); const {id}=await context.params; const data=tourSchema.partial().parse(await request.json()); return Response.json(await db.tour.update({where:{id},data})); }
  catch(error) { return apiError(error); }
}
