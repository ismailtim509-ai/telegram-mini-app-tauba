import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { tourSchema } from '@/lib/validation';
export async function GET(request: Request) {
  try { requireAdmin(request); return Response.json(await db.tour.findMany({orderBy:{updatedAt:'desc'}})); }
  catch(error) { return apiError(error); }
}
export async function POST(request: Request) {
  try { requireAdmin(request); const data=tourSchema.parse(await request.json()); return Response.json(await db.tour.create({data}),{status:201}); }
  catch(error) { return apiError(error); }
}
