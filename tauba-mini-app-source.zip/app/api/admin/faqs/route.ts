import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { z } from 'zod';
const schema=z.object({question:z.string().trim().min(5).max(300),answer:z.string().trim().min(5).max(3000),sortOrder:z.number().int().default(0),isPublished:z.boolean().default(true)});
export async function GET(request: Request) { try { requireAdmin(request); return Response.json(await db.faq.findMany({orderBy:{sortOrder:'asc'}})); } catch(error) { return apiError(error); } }
export async function POST(request: Request) { try { requireAdmin(request); return Response.json(await db.faq.create({data:schema.parse(await request.json())}),{status:201}); } catch(error) { return apiError(error); } }
