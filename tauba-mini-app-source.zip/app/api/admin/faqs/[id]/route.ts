import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { z } from 'zod';
const schema=z.object({question:z.string().trim().min(5).max(300),answer:z.string().trim().min(5).max(3000),sortOrder:z.number().int(),isPublished:z.boolean()}).partial();
export async function PATCH(request: Request, context:{params:Promise<{id:string}>}) { try { requireAdmin(request); const {id}=await context.params; return Response.json(await db.faq.update({where:{id},data:schema.parse(await request.json())})); } catch(error) { return apiError(error); } }
