import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
import { z } from 'zod';
export async function PATCH(request: Request, context:{params:Promise<{id:string}>}) {
  try { requireAdmin(request); const {id}=await context.params; const {status}=z.object({status:z.enum(['new','contacted','confirmed','closed'])}).parse(await request.json()); return Response.json(await db.application.update({where:{id},data:{status}})); }
  catch(error) { return apiError(error); }
}
