import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
export async function GET(request: Request) {
  try { requireAdmin(request); return Response.json(await db.application.findMany({include:{tour:{select:{title:true,dateLabel:true}}},orderBy:{createdAt:'desc'}})); }
  catch(error) { return apiError(error); }
}
