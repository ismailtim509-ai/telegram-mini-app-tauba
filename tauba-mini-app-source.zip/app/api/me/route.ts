import { getIdentity, isAdmin } from '@/lib/auth';
import { apiError } from '@/lib/api';
export async function GET(request: Request) {
  try { const user=getIdentity(request); return Response.json({user,admin:isAdmin(user.id)}); }
  catch(error) { return apiError(error); }
}
