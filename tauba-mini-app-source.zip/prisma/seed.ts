import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();
const sourceUrl = 'https://taubatour.ru/';
const common = {
  kind: 'umrah', currency: 'USD', sourceUrl, needsConfirmation: true, isPublished: true,
  route: ['Махачкала', 'Дубай', 'Медина', 'Мекка', 'Джидда', 'Дубай', 'Махачкала'],
  included: ['Авиабилеты', 'Встреча в аэропорту', 'Трансферы', 'Сопровождение гида', 'Экскурсии', 'Зам-зам 5 л'],
  excursions: ['Ухуд', 'Ров', 'Арафа', 'Ан-Нур', 'Муздалифа', 'Мина', 'Мечеть аль-Куба'],
  transfers: 'Встреча в аэропорту и трансферы',
  images: ['https://taubatour.ru/wp-content/uploads/2025/12/38827599-d2ba-5e20-bc38-f6a056a71c23.jpeg']
};

const tours = [
  { id:'umrah-oct-07', title:'Умра • 7–17 октября', category:'economy', dateLabel:'7–17 октября · год уточняется', price:1490, medinaDays:3, makkahDays:7, meals:'Без питания', guide:'Булат', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Mias al Madina',note:'или аналог, 4★'},{city:'Мекка',name:'Al Dana',note:'или аналог, 4★'}] },
  { id:'umrah-oct-08', title:'Умра • 8–22 октября', category:'standard', dateLabel:'8–22 октября · год уточняется', price:1650, medinaDays:4, makkahDays:10, meals:'Завтраки включены', guide:'Саид Мединский', baggage:'10 кг + 5 кг ручная кладь', route:['Махачкала','Джидда','Медина','Мекка','Джидда','Махачкала'], hotels:[{city:'Медина',name:'Grand Alshahba',note:'3★'},{city:'Мекка',name:'Holiday Inn',note:'4★'}], conditions:'На сайте указано: осталось несколько мест. Актуальное наличие требует подтверждения.' },
  { id:'umrah-oct-11', title:'Умра • 11–20 октября', category:'lux', status:'soldout', dateLabel:'11–20 октября · год уточняется', price:2490, medinaDays:4, makkahDays:5, meals:'Завтраки включены', guide:'Мухаммад Абу Усама', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Zam Zam Pulman',note:'или аналог, 5★'},{city:'Мекка',name:'Fairmont Hotel',note:'или аналог, 5★'}] },
  { id:'umrah-oct-29', title:'Умра • 29 октября – 7 ноября', category:'standard', dateLabel:'29 октября – 7 ноября · год уточняется', price:1690, medinaDays:4, makkahDays:5, meals:'Завтраки включены', guide:'Саид Мединский', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Mias al Madina',note:'или аналог, 4★'},{city:'Мекка',name:'Holiday',note:'или аналог, 4★'}] },
  { id:'umrah-nov-03', title:'Умра • 3–13 ноября', category:'lux', dateLabel:'3–13 ноября · год уточняется', price:2490, medinaDays:4, makkahDays:6, meals:'Завтраки включены', guide:'Мухаммад Абу Усама', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Zam Zam Pulman',note:'или аналог, 5★'},{city:'Мекка',name:'Fairmont Hotel',note:'или аналог, 5★'}] },
  { id:'umrah-nov-12', title:'Умра • 12–22 ноября', category:'comfort', dateLabel:'12–22 ноября · год уточняется', price:2150, medinaDays:4, makkahDays:6, meals:'Завтраки включены', guide:'Юсуф Абу Закария', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Mias al Madina',note:'или аналог, 4★'},{city:'Мекка',name:'Jabal Omar',note:'или аналог, 5★'}] },
  { id:'umrah-nov-15', title:'Умра • 15–25 ноября', category:'economy', dateLabel:'15–25 ноября · год уточняется', price:1490, medinaDays:3, makkahDays:7, meals:'Без питания', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Mias al Madinah',note:'или аналог, 4★'},{city:'Мекка',name:'Al Dana',note:'или аналог, 4★'}] },
  { id:'umrah-nov-22', title:'Умра • 22 ноября – 2 декабря', category:'standard', dateLabel:'22 ноября – 2 декабря · год уточняется', price:1690, medinaDays:4, makkahDays:6, meals:'Завтраки включены', guide:'Ислам Абу Теймия', baggage:'30 кг + 7 кг ручная кладь', hotels:[{city:'Медина',name:'Mias al Madinah',note:'или аналог, 4★'},{city:'Мекка',name:'Holiday',note:'или аналог, 4★'}] }
];

async function main() {
  for (const tour of tours) await db.tour.upsert({where:{id:tour.id},update:{},create:{...common,...tour,status:'status' in tour ? tour.status : 'check'}});
  const faq = [
    ['Нужен ли опыт для совершения Умры?','Нет. На сайте TAUBA TOUR указано, что команда объясняет этапы и сопровождает паломников.'],
    ['Что входит в стоимость?','Состав зависит от программы. Откройте конкретный тур и проверьте включённые услуги; условия и стоимость уточняются перед бронированием.'],
    ['Когда отправлять документы?','После консультации менеджер уточнит список и сроки документов для выбранной поездки. Не отправляйте паспорт через эту демонстрационную форму.']
  ];
  for (let i=0;i<faq.length;i++) await db.faq.upsert({where:{id:`faq-${i+1}`},update:{},create:{id:`faq-${i+1}`,question:faq[i][0],answer:faq[i][1],sortOrder:i}});
}
main().finally(()=>db.$disconnect());
