CREATE TABLE "Tour" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "kind" TEXT NOT NULL DEFAULT 'umrah',
  "category" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'check',
  "startDate" TIMESTAMP(3),
  "endDate" TIMESTAMP(3),
  "dateLabel" TEXT,
  "price" INTEGER,
  "currency" TEXT NOT NULL DEFAULT 'USD',
  "makkahDays" INTEGER,
  "medinaDays" INTEGER,
  "route" JSONB,
  "hotels" JSONB,
  "meals" TEXT,
  "flights" TEXT,
  "baggage" TEXT,
  "transfers" TEXT,
  "guide" TEXT,
  "excursions" JSONB,
  "included" JSONB,
  "conditions" TEXT,
  "availability" INTEGER,
  "images" JSONB,
  "isPublished" BOOLEAN NOT NULL DEFAULT false,
  "isArchived" BOOLEAN NOT NULL DEFAULT false,
  "sourceUrl" TEXT,
  "sourceCheckedAt" TIMESTAMP(3),
  "needsConfirmation" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Tour_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "Application" (
  "id" TEXT NOT NULL,
  "telegramId" TEXT NOT NULL,
  "tourId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "people" INTEGER NOT NULL,
  "comment" TEXT,
  "consentAt" TIMESTAMP(3) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'new',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Application_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "Faq" (
  "id" TEXT NOT NULL,
  "question" TEXT NOT NULL,
  "answer" TEXT NOT NULL,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "isPublished" BOOLEAN NOT NULL DEFAULT true,
  CONSTRAINT "Faq_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Application_telegramId_createdAt_idx" ON "Application"("telegramId", "createdAt");
ALTER TABLE "Application" ADD CONSTRAINT "Application_tourId_fkey" FOREIGN KEY ("tourId") REFERENCES "Tour"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
