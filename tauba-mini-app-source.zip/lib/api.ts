import { AuthError } from './auth';
import { ZodError } from 'zod';

export function apiError(error: unknown): Response {
  if (error instanceof AuthError) return Response.json({error:error.message},{status:error.message === 'Admin access denied' ? 403 : 401});
  if (error instanceof ZodError) return Response.json({error:'Проверьте заполнение формы',details:error.flatten()},{status:400});
  if (error instanceof SyntaxError) return Response.json({error:'Некорректный JSON'},{status:400});
  console.error('API request failed', error instanceof Error ? error.name : 'UnknownError');
  return Response.json({error:'Сервис временно недоступен'},{status:500});
}
