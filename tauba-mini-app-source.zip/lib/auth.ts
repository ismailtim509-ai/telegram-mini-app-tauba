import crypto from 'node:crypto';

export type TelegramIdentity = { id: string; first_name?: string; last_name?: string; username?: string; photo_url?: string };
export class AuthError extends Error {}

export function verifyInitData(raw: string, botToken: string, now = Date.now()): TelegramIdentity {
  if (!raw || !botToken) throw new AuthError('Telegram authentication unavailable');
  const params = new URLSearchParams(raw);
  const hash = params.get('hash');
  const authDate = Number(params.get('auth_date'));
  if (!hash || !/^[a-f0-9]{64}$/i.test(hash) || !Number.isInteger(authDate)) throw new AuthError('Invalid Telegram data');
  const age = Math.floor(now / 1000) - authDate;
  if (age < -60 || age > 86400) throw new AuthError('Expired Telegram data');
  const pairs = [...params.entries()].filter(([key]) => key !== 'hash').sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
  if (new Set(pairs.map(([key]) => key)).size !== pairs.length) throw new AuthError('Duplicate Telegram data');
  const checkString = pairs.map(([key, value]) => `${key}=${value}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = crypto.createHmac('sha256', secret).update(checkString).digest();
  const received = Buffer.from(hash, 'hex');
  if (received.length !== expected.length || !crypto.timingSafeEqual(received, expected)) throw new AuthError('Invalid Telegram signature');
  let user: unknown;
  try { user = JSON.parse(params.get('user') ?? ''); } catch { throw new AuthError('Missing Telegram user'); }
  if (!user || typeof user !== 'object' || !('id' in user) || !Number.isSafeInteger(Number(user.id))) throw new AuthError('Missing Telegram user');
  const identity = user as Record<string, unknown>;
  return { id: String(identity.id), first_name: typeof identity.first_name === 'string' ? identity.first_name : undefined, last_name: typeof identity.last_name === 'string' ? identity.last_name : undefined, username: typeof identity.username === 'string' ? identity.username : undefined, photo_url: typeof identity.photo_url === 'string' ? identity.photo_url : undefined };
}

export function getIdentity(request: Request): TelegramIdentity {
  return verifyInitData(request.headers.get('x-telegram-init-data') ?? '', process.env.BOT_TOKEN ?? '');
}

export function isAdmin(id: string, adminIds = process.env.ADMIN_IDS ?? ''): boolean {
  return adminIds.split(',').map(value => value.trim()).filter(Boolean).includes(id);
}

export function requireAdmin(request: Request): TelegramIdentity {
  const user = getIdentity(request);
  if (!isAdmin(user.id)) throw new AuthError('Admin access denied');
  return user;
}
