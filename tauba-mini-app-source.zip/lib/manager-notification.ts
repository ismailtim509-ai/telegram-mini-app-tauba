/** Optional manager alert. Application persistence never depends on Telegram delivery. */
export async function notifyManager(application:{id:string;name:string;phone:string;people:number}, tourTitle:string):Promise<void> {
  const token=process.env.BOT_TOKEN;
  const chatId=process.env.MANAGER_CHAT_ID;
  if (!token||!chatId) return;
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body:JSON.stringify({chat_id:chatId,text:`Новая заявка #${application.id}\nТур: ${tourTitle}\nИмя: ${application.name}\nТелефон: ${application.phone}\nЧеловек: ${application.people}`,disable_web_page_preview:true}),
      signal:AbortSignal.timeout(5000)
    });
    if (!response.ok) console.error('Manager notification failed');
  } catch {
    console.error('Manager notification failed');
  }
}
