import { describe, expect, it } from 'vitest';
import crypto from 'node:crypto';
import { isAdmin, verifyInitData } from '../lib/auth';

const token='test-token';
const now=Date.UTC(2026,9,3,12);
function signedData(userId:number, authDate=Math.floor(now/1000)) {
  const pairs=[['auth_date',String(authDate)],['user',JSON.stringify({id:userId,first_name:'Тест'})]];
  const secret=crypto.createHmac('sha256','WebAppData').update(token).digest();
  const hash=crypto.createHmac('sha256',secret).update(pairs.map(([k,v])=>`${k}=${v}`).join('\n')).digest('hex');
  return new URLSearchParams([...pairs,['hash',hash]]).toString();
}
describe('Telegram authentication',()=>{
  it('accepts a valid signature and derives identity from signed data',()=>expect(verifyInitData(signedData(123),token,now).id).toBe('123'));
  it('rejects a forged Telegram ID',()=>expect(()=>verifyInitData(signedData(123).replace('%22id%22%3A123','%22id%22%3A999'),token,now)).toThrow());
  it('rejects missing and invalid signatures',()=>{expect(()=>verifyInitData('user=%7B%22id%22%3A1%7D',token,now)).toThrow();expect(()=>verifyInitData(signedData(1).replace(/hash=[a-f0-9]+/,'hash='+ '0'.repeat(64)),token,now)).toThrow();});
  it('rejects expired auth data',()=>expect(()=>verifyInitData(signedData(1,Math.floor(now/1000)-86401),token,now)).toThrow());
  it('does not grant admin rights to an ordinary user',()=>{expect(isAdmin('123','456,789')).toBe(false);expect(isAdmin('456','456,789')).toBe(true);});
});
