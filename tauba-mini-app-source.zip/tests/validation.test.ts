import { describe, expect, it } from 'vitest';
import { applicationSchema, tourSchema } from '../lib/validation';
describe('API input validation',()=>{
  it('requires explicit consent and valid contact data',()=>{expect(applicationSchema.safeParse({tourId:'t',name:'A',phone:'123',people:0,consent:false}).success).toBe(false);expect(applicationSchema.safeParse({tourId:'t',name:'Амин',phone:'+7 999 123-45-67',people:2,consent:true}).success).toBe(true);});
  it('rejects invalid availability and non-catalog categories',()=>{expect(tourSchema.safeParse({title:'Новая умра',kind:'umrah',category:'invented',status:'available',availability:-1}).success).toBe(false);});
});
